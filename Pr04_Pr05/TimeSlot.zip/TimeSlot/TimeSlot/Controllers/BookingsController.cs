﻿using Microsoft.AspNetCore.Mvc;
using TimeSlot.Models;
using TimeSlot.Persistence;
using TimeSlot.Services;
using TimeSlot.ViewModels;

namespace TimeSlot.Controllers
{
    public class BookingsController : Controller
    {
        private IRoomRepository roomRepository;
        private IBookingService bookingService;

        public BookingsController(IBookingService bookingService, IRoomRepository roomRepository)
        {
            this.roomRepository = roomRepository;
            this.bookingService = bookingService;
        }

        public IActionResult Index()
        {
            var bookings = bookingService.GetAll();
            return View(bookings);
        }

        public IActionResult Add(int? id)
        {
            ViewBag.Action = "add";

            var bookingVM = new BookingViewModel
            {
                Rooms = roomRepository.GetAll()
            };

            var date = DateTime.Now;
            bookingVM.Booking.StartTime = new DateTime(date.Year, date.Month, date.Day, date.Hour, date.Minute, 0);
            bookingVM.Booking.EndTime = new DateTime(date.Year, date.Month, date.Day, date.Hour + 1, date.Minute, 0);

            if (id != null) bookingVM.Booking.RoomId = id.Value;

            return View(bookingVM);
        }

        [HttpPost]
        public IActionResult Add(BookingViewModel bookingVM)
        {
            BookingResult result = bookingService.Add(bookingVM.Booking);
            if (!result.IsSuccelful)
            {
                ModelState.AddModelError(result.Key, result.ErrorMessage);
            }

            if (!ModelState.IsValid)
            {
                bookingVM.Rooms = roomRepository.GetAll();
                ViewBag.Action = "add";

                return View(bookingVM);
            }

            return RedirectToAction("Index");
        }

        public IActionResult Edit(int? id)
        {
            BookingViewModel bookingVM = new BookingViewModel
            {
                Booking = bookingService.GetById(id ?? 0),
                Rooms = roomRepository.GetAll()
            };

            ViewBag.Action = "edit";

            return View(bookingVM);
        }

        [HttpPost]
        public IActionResult Edit(BookingViewModel bookingVM)
        {
            BookingResult result = bookingService.Update(bookingVM.Booking);
            if (!result.IsSuccelful)
            {
                ModelState.AddModelError(result.Key, result.ErrorMessage);
            }

            if (!ModelState.IsValid)
            {
                bookingVM.Rooms = roomRepository.GetAll();

                ViewBag.Action = "edit";

                return View(bookingVM);
            }

            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            bookingService.Delete(id);

            return RedirectToAction("Index");   
        }
    }
}

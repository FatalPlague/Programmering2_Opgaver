﻿using Microsoft.EntityFrameworkCore;
using TimeSlot.Data;
using TimeSlot.Models;

namespace TimeSlot.Persistence
{
    public class BookingRepository : IBookingRepository
    {
        private readonly TimeSlotContext context;

        public BookingRepository(TimeSlotContext context)
        {
            this.context = context;
        }

        public void Add(Booking booking)
        {
            context.Bookings.Add(booking);
            context.SaveChanges();
        }

        public void Delete(int id)
        {
            context.Bookings.Where(b => b.BookingId == id).ExecuteDelete();
        }

        public List<Booking> GetAll()
        {
            return context.Bookings.Include(r => r.Room).ToList();
        }

        public Booking? GetById(int id)
        {
            return context.Bookings.FirstOrDefault(b => b.BookingId == id);
        }

        public void Update(Booking booking)
        {
            context.Bookings.Where(b => b.BookingId == booking.BookingId)
                    .ExecuteUpdate(b => b
                .SetProperty(b => b.Title, booking.Title)
                .SetProperty(b => b.StartTime, booking.StartTime)
                .SetProperty(b => b.EndTime, booking.EndTime)
                .SetProperty(b => b.RoomId, booking.RoomId)
                );
        }
    }
}
